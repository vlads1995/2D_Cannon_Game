﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIManager : MonoBehaviour
{
    [SerializeField]
    private GameObject cannonChooseMenu;

    public void CannonChooseMenu()
    {
        cannonChooseMenu.SetActive(true);
    }

    public void CloseMenu()
    {
        cannonChooseMenu.SetActive(false);
    }
}
